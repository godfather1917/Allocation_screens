import { call, put, takeLatest } from "redux-saga/effects";
import {
  getRULESTYPESuccess,
  getRULESTYPEError,
  getNEEDTYPESuccess,
  getNEEDTYPEError,
  getHIERARCHYTYPESuccess,
  getHIERARCHYTYPEError,
  getALLOCATETOTYPESuccess,
  getALLOCATETOTYPEError,
  getFETCHLOCATIONDATASuccess,
  getFETCHLOCATIONDATAError,
} from "../Action/rules&location";
import * as actions from "../constant";
import axiosCall from "../../services/index";
import { API } from "../../services/api";


function* fetchRULESTYPESaga(action) {
  try {
    const response = yield call(axiosCall, "GET", API.FETCHRULETYPE,action.payload);
    if (response?.status == 200) {
      yield put(getRULESTYPESuccess({ ruleType: response?.data }));
    } else {
      yield put(getRULESTYPEError(response?.data?.message));
    }
  } catch (e) {
    yield put(getRULESTYPEError(e.message));
  }
}

export function* RULESTYPEData() {
  yield takeLatest(actions.GET_RULESTYPE_REQUEST, fetchRULESTYPESaga);
}

function* fetchNEEDTYPESaga(action) {
  try {
    const response = yield call(axiosCall, "GET", API.FETCHNEED,action.payload);
    // console.log("responsealloc_no",response);
    if (response?.status == 200) {
      yield put(getNEEDTYPESuccess({ Need: response?.data }));
    } else {
      yield put(getNEEDTYPEError(response?.data?.message));
    }
  } catch (e) {
    yield put(getNEEDTYPEError(e.message));
  }
}

export function* NEEDTYPEData() {
  yield takeLatest(actions.GET_NEEDTYPE_REQUEST, fetchNEEDTYPESaga);
}


function* fetchHIERARCHYTYPESaga(action) {
  try {
    const response = yield call(axiosCall, "GET", API.FETCHHIERARCHY,action.payload);
    // console.log("responsealloc_no",response);
    if (response?.status == 200) {
      yield put(getHIERARCHYTYPESuccess({ Hierarchy: response?.data }));
    } else {
      yield put(getHIERARCHYTYPEError(response?.data?.message));
    }
  } catch (e) {
    yield put(getHIERARCHYTYPEError(e.message));
  }
}

export function* HIERARCHYTYPEData() {
  yield takeLatest(actions.GET_HIERARCHYTYPE_REQUEST, fetchHIERARCHYTYPESaga);
}


function* fetchALLOCATETOTYPESaga(action) {
  try {
    const response = yield call(axiosCall, "GET", API.FETCHALLOCATETO,action.payload);
    // console.log("responsealloc_no",response);
    if (response?.status == 200) {
      yield put(getALLOCATETOTYPESuccess({ Allocateto: response?.data }));
    } else {
      yield put(getALLOCATETOTYPEError(response?.data?.message));
    }
  } catch (e) {
    yield put(getALLOCATETOTYPEError(e.message));
  }
}

export function* ALLOCATETOTYPEData() {
  yield takeLatest(actions.GET_ALLOCATETOTYPE_REQUEST, fetchALLOCATETOTYPESaga);
}

function* fetchFETCHLOCATIONDATASaga(action) {
  try {
    const response = yield call(axiosCall, "POST", API.FETCHLOCATIONDATA,action.payload);
    // console.log("responsealloc_no",response);
    if (response?.status == 200) {
      yield put(getFETCHLOCATIONDATASuccess({ totalData: response?.data }));
    } else {
      yield put(getFETCHLOCATIONDATAError(response?.data?.message));
    }
  } catch (e) {
    yield put(getFETCHLOCATIONDATAError(e.message));
  }
}

export function* FETCHLOCATIONDATAData() {
  yield takeLatest(actions.GET_FETCHLOCATIONDATA_REQUEST, fetchFETCHLOCATIONDATASaga);
}