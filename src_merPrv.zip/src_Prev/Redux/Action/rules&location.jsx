import { createAction } from "redux-actions";
import * as actions from "../constant";

export const getRULESTYPERequest = createAction(
  actions.GET_RULESTYPE_REQUEST
);
export const getRULESTYPESuccess = createAction(
  actions.GET_RULESTYPE_SUCCESS
);
export const getRULESTYPEError = createAction(
  actions.GET_RULESTYPE_ERROR
);
export const getNEEDTYPERequest = createAction(
  actions.GET_NEEDTYPE_REQUEST
);
export const getNEEDTYPESuccess = createAction(
  actions.GET_NEEDTYPE_SUCCESS
);
export const getNEEDTYPEError = createAction(
  actions.GET_NEEDTYPE_ERROR
);
export const getALLOCATETOTYPERequest = createAction(
  actions.GET_ALLOCATETOTYPE_REQUEST
);
export const getALLOCATETOTYPESuccess = createAction(
  actions.GET_ALLOCATETOTYPE_SUCCESS
);
export const getALLOCATETOTYPEError = createAction(
  actions.GET_ALLOCATETOTYPE_ERROR
);
export const getHIERARCHYTYPERequest = createAction(
  actions.GET_HIERARCHYTYPE_REQUEST
);
export const getHIERARCHYTYPESuccess = createAction(
  actions.GET_HIERARCHYTYPE_SUCCESS
);
export const getHIERARCHYTYPEError = createAction(
  actions.GET_HIERARCHYTYPE_ERROR
);
export const getFETCHLOCATIONDATARequest = createAction(
  actions.GET_FETCHLOCATIONDATA_REQUEST
);
export const getFETCHLOCATIONDATASuccess = createAction(
  actions.GET_FETCHLOCATIONDATA_SUCCESS
);
export const getFETCHLOCATIONDATAError = createAction(
  actions.GET_FETCHLOCATIONDATA_ERROR
);
