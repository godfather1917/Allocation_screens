import React from "react";
import { default as ReactSelect } from "react-select";
import { useDispatch, useSelector } from "react-redux";
import "./Right.css";
import { useState, useRef, useEffect } from "react";
import axios from "axios";
import { DataGrid, GridCellModes } from "@mui/x-data-grid";
import { CONFIG } from "../../services/config";

// import data12 from './data.json'
// import locationlistjson from '../Components/data/store_list.json'
// import locationtraitsjson from '../Components/data/store_traits.json'
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import { Button } from "@mui/material";
import Box from "@mui/material/Box";
import {
  getFETCHLOCATIONDATARequest,
} from "../../Redux/Action/rules&location";
import InputLabel from '@mui/material/InputLabel';
import { makeStyles, withStyles } from "@mui/styles";
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';


const useStyles = makeStyles({
  maindiv: {
    position: "relative",
    // backgroundColor:"yellow",
    // width:"100%",
    width: "calc(95vw - 0px)",
    "& table": {
      "& tr": {
        "& td:nth-child(29)": {
          display: "none",
        },
        "& td:nth-child(30)": {
          display: "none",
        },
        "& td:nth-child(31)": {
          display: "none",
        },
      },
    },
  },
  boxDiv: {
    textAlign: "initial",
    position: "relative",
    maxWidth: "1400px",
    // backgroundColor:"yellow"
  },
  uploaddiv: {
    display: "flex",
    alignItems: "center",
    marginTop: "50px",
    textAlign: "start",
    gap: 20,
    // backgroundColor:"lightgreen"
  },
  TitleHead: {
    // height: "25px",
    position: "sticky",
    top: -1,
  },
  GobackDiv: {
    cursor: "pointer",
  },
  textField: {
    marginRight: "10px !important",
  },
  dateField: {
    "& .MuiInput-input": {
      color: "rgba(102,102,102,1)",
    },
  },
  popUp: {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    backgroundColor: "white",
    border: "2px solid #000",
    boxShadow: 24,
    padding: "20px 20px 20px 20px",
  },
  header_container: {
    display: "inline-block",
    // marginTop: "0.2rem",
    // padding: "1rem 1rem",
    // text-align: center;
  },
  header_child: {
    display: "inline-block",
    // border: "1px solid red",
    padding: "0rem 0.2rem",
    verticalAlign: "middle",
  },
  input: {
    // width: "250px",
    height: 37.8,
    // backgroundColor:"#f0f0f0",
    '& input + fieldset': {
      // borderColor: 'gray',
      borderRadius: "0",
      boxShadow: "rgba(0, 0, 0, 0.19) 0px 1px 2px, rgba(0, 0, 0, 0.23) 0px 2px 2px"
    },
  },
  divBoxLeft: {
    width: "100%",
    float: "left"
  },
})


const initialsearch = {
  LOCATION: [],
  LOCATION_LIST: [],
  LOCATION_TRAITS: [],
  EXCLUDE_LOCATION: [],
}


const RightContainer = ({ new_table, setNew_table }) => {
  const [data, setData] = useState([]);
  const [rows, setRows] = useState([]);
  const [locations, setLocations] = useState([])
  //to store list of loc as array
  const [locArray, setLocArray] = useState([])
  const [locDescArray, setLocDescArray] = useState([])
  const [clearanceArray, setClearanceArray] = useState([])
  const [statusArray, setStatusArray] = useState([])

  const [tableData, settableData] = useState([])
  const [locationsTraits, setLocationTraits] = useState([])
  const [locationList, setLocationList] = useState([])
  const [check1, setCheck1] = useState(false)
  const [check2, setCheck2] = useState(true);
  const [searchData, setSearchData] = useState(initialsearch);
  const [inputLoc, setInputLoc] = useState("");
  const [valLoc, setValLoc] = useState([]);
  const [inputLoc1, setInputLoc1] = useState("");
  const [valLoc1, setValLoc1] = useState([]);
  const [inputLoc2, setInputLoc2] = useState("");
  const [inputLoc3, setInputLoc3] = useState("");
  const [valLoc2, setValLoc2] = useState([]);
  const [valLoc3, setValLoc3] = useState([]);
  const [post, updatePost] = useState({ title: '' })
  const [page, setPage] = useState(0);
  const [splitpage, setSplitpage] = useState([])
  const [table_data, setTable_data] = useState([])
  const [selectedLoc, setSelectedLoc] = useState([])
  const [selectedLocList, setSelectedLocList] = useState([])
  const [selectedLoctrait, setSelectedLoctrait] = useState([])
  const [selectedExcluded, setSelectedExcluded] = useState([])
  const [selectedRows, setSelectedRows] = useState([])
  const [search, setsearch] = useState({
    "location": "",
    "loc_desc": "",
    "loc_type": "",
    "default_wh": "",
    "group_id": "",
    "group_desc": ""
  });
  // const [searcharray, setSearcharray] = useState([])
  const [status, setStatus] = useState([])
  const [clearance, setClearance] = useState([])

  //////////////////////////////////////////////
  /////////////////////////
  ///////////////////////////////////////////////////////
  const [totalData, setTotalData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isSearch, setSearch] = useState(false);

  const RulesLocationRightClasses = useStyles();

  const RulesLocationRightData = useSelector(
    (state) => state.RulesLocationReducers
  );

  const dispatch = useDispatch();


  useEffect(() => {
    if (
      RulesLocationRightData?.data?.totalData
      && Array.isArray(RulesLocationRightData?.data?.totalData)
    ) {
      setTotalData(RulesLocationRightData?.data?.totalData);
      setLoading(false);
      // } else if (
      //     RulesLocationRightData?.data?.Need
      //     && Array.isArray(RulesLocationRightData?.data?.Need)
      // ) {
      //     setNeed(RulesLocationRightData?.data?.Need);
      //     setLoading(false);
    } else {
      setSearch(false);
    }
  }, [RulesLocationRightData?.data]);


  const HandleAddButton = () => {
    if(check1){
      setLoading(true);
    dispatch(getFETCHLOCATIONDATARequest([{}]));
    }

  }


  const handleswitchcheck = (e, val) => {
    console.log("e::", e, val, e.target.name)
    if (e.target.name === "check1") {
        setCheck1(val)
    }
  }

  console.log("totalData::",totalData);

















  ///////////////////////////////////////////
  ///////////////
  //////////////////////////////////////////////

  const likeLocAction = () => {
    return (
      <strong style={{ paddingRight: "5px" }}>
        LIKE LOC
        <Button
          variabe="contained"
          color="primary"
          size="small"
          onClick={($event) => copyDownLikeLoc($event)}
        >
          <ContentCopyIcon />
        </Button>
      </strong>
    )
  }


  const copyDownLikeLoc = (e) => {
    console.log(e);
    e.stopPropagation()
    e.preventDefault()
    console.log(selectedRows);
    const temp = [].concat(tableData);
    let selectedRow = tableData[temp.findIndex(p => p.id == selectedRows[0])]
    //   let updatedData=tableData.forEach((data,index)=>{
    // return data
    //   })
    selectedRows.forEach((data) => {
      let row = temp.filter((res) => res.id == data)
      let index = temp.findIndex(p => p.id == data)
      console.log();
      let location = locDescArray.filter((res) => { return res.label.includes(selectedRow.LIKE_LOC) })
      console.log(location, locDescArray);
      temp[index] = { ...row[0], LIKE_LOC: selectedRow.LIKE_LOC, LIKE_LOC_DESC: location[0].label }
      console.log(temp, index);
      //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
    })
    settableData(temp)
  }
  //Table colums data
  const likeLocDescAction = (e) => {
    // e.preventDefault()

    return (
      <strong style={{ paddingRight: "5px" }}>
        LIKE LOC DESC
        <Button
          variabe="contained"
          color="primary"
          size="small"
          onClick={($event) => copyDownLikeLocDesc($event)}
        >
          <ContentCopyIcon />
        </Button>
      </strong>
    )
  }

  const copyDownLikeLocDesc = (e) => {
    e.stopPropagation()
    e.preventDefault()
    console.log(e);
    const temp = [].concat(tableData);
    let selectedRow = tableData[temp.findIndex(p => p.id == selectedRows[0])]
    //   let updatedData=tableData.forEach((data,index)=>{
    // return data
    //   })
    selectedRows.forEach((data) => {
      let row = temp.filter((res) => res.id == data)
      let index = temp.findIndex(p => p.id == data)
      console.log(selectedRow);
      temp[index] = { ...row[0], LIKE_LOC_DESC: selectedRow.LIKE_LOC_DESC }
      console.log(temp, index);
      //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
    })
    settableData(temp)
  }

  const likeWeightAction = (e) => {
    // e.preventDefault()

    return (
      <strong style={{ paddingRight: "5px" }}>
        WEIGHT %
        <Button
          variabe="contained"
          color="primary"
          size="small"
          onClick={($event) => ($event)}
        >
          <ContentCopyIcon />
        </Button>
      </strong>
    )
  }

  const copyDownWeight = (e) => {
    e.stopPropagation()
    e.preventDefault()
    console.log(e);
    const temp = [].concat(tableData);
    let selectedRow = tableData[temp.findIndex(p => p.id == selectedRows[0])]
    //   let updatedData=tableData.forEach((data,index)=>{
    // return data
    //   })
    selectedRows.forEach((data) => {
      let row = temp.filter((res) => res.id == data)
      let index = temp.findIndex(p => p.id == data)
      console.log(selectedRow);
      temp[index] = { ...row[0], WEIGHT: selectedRow.WEIGHT }
      console.log(temp, index);
      //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
    })
    settableData(temp)
  }

  const likeClearanceAction = (e) => {
    // e.preventDefault()

    return (
      <strong style={{ paddingRight: "5px" }}>
        CLEARANCE FLAG
        <Button
          variabe="contained"
          color="primary"
          size="small"
          onClick={($event) => copyDownClearance($event)}
        >
          <ContentCopyIcon />
        </Button>
      </strong>
    )
  }

  const copyDownClearance = (e) => {
    e.stopPropagation()
    e.preventDefault()
    console.log(e);
    const temp = [].concat(tableData);
    let selectedRow = tableData[temp.findIndex(p => p.id == selectedRows[0])]
    //   let updatedData=tableData.forEach((data,index)=>{
    // return data
    //   })
    selectedRows.forEach((data) => {
      let row = temp.filter((res) => res.id == data)
      let index = temp.findIndex(p => p.id == data)
      console.log(selectedRow);
      temp[index] = { ...row[0], CLEARANCE_FLAG: selectedRow.CLEARANCE_FLAG }
      console.log(temp, index);
      //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
    })
    settableData(temp)
  }


  const likeStatusAction = (e) => {
    // e.preventDefault()

    return (
      <strong style={{ paddingRight: "5px" }}>
        STATUS
        <Button
          variabe="contained"
          color="primary"
          size="small"
          onClick={($event) => copyDownStatus($event)}
        >
          <ContentCopyIcon />
        </Button>
      </strong>
    )
  }

  const copyDownStatus = (e) => {
    e.stopPropagation()
    e.preventDefault()
    console.log(e);
    const temp = [].concat(tableData);
    let selectedRow = tableData[temp.findIndex(p => p.id == selectedRows[0])]
    //   let updatedData=tableData.forEach((data,index)=>{
    // return data
    //   })
    selectedRows.forEach((data) => {
      let row = temp.filter((res) => res.id == data)
      let index = temp.findIndex(p => p.id == data)
      console.log(selectedRow);
      temp[index] = { ...row[0], STATUS: selectedRow.STATUS }
      console.log(temp, index);
      //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
    })
    settableData(temp)
  }

  const columns = [

    {
      field: "LOCATION",
      headerName: "LOCATION",
      width: 150,
    },
    {
      field: "LOC_DESC",
      headerName: "LOC DESC",
      width: 150,
    },
    {
      field: "LOC_TYPE",
      headerName: "LOC TYPE",
      width: 110,
    },
    {
      field: "DEFAULT_WH",
      headerName: "DEF WH",
      width: 160,
    },
    {
      field: "GROUP_ID",
      headerName: "GROUP",
      width: 160,
    },
    {
      field: "GROUP_DESC",
      headerName: "GROUP DESC",
      width: 250,
    },
    {
      field: "LIKE_LOC",
      headerName: "LIKE LOC",
      // icon: <ContentCopyIcon sx={{ color: "#b4b4b4" }} />,
      editable: true,
      type: "singleSelect",
      valueOptions: locArray,
      width: 250,
      renderHeader: likeLocAction
    },
    {
      field: `LIKE_LOC_DESC`,
      headerName: "LIKE LOC DESC",
      type: "singleSelect",
      valueOptions: locDescArray,
      editable: true,
      width: 250,
      renderHeader: likeLocDescAction
    },
    {
      field: "WEIGHT",
      headerName: "WEIGHT %",
      description: "This column has a value getter and is not sortable.",
      editable: true,

      width: 250,
      renderHeader: likeWeightAction
    },
    {
      field: "CLEARANCE_FLAG",
      headerName: "CLEARANCE FLAG",
      type: "singleSelect",
      valueOptions: clearanceArray,
      editable: true,
      width: 250,
      renderHeader: likeClearanceAction
    },
    {
      field: "STATUS",
      headerName: "STATUS",
      type: "singleSelect",
      valueOptions: statusArray,
      editable: true,
      width: 250,
      renderHeader: likeStatusAction
    }
  ];

  const chack = "chacked"


  const handledata_change = async () => {
    if (check1) {

      setTable_data(tableData)
      setNew_table(tableData)

    } else {
      setTable_data([])
      setNew_table([])
    }

  }



  const r1 = useRef()
  const r2 = useRef()
  const r3 = useRef()
  const r4 = useRef()


  const selectLocation = (event, value) => {
    //console.log("event:", event)
    //console.log("value:", value)
    console.log(value);
    setSelectedLoc(event);
    let selectedLocation = [];
    if (value.option) {
      valLoc.push(value.option);
      // if (value.option.LOCATION===parseInt(inputLoc)){ 
      //   //////console.log(1234)
      //   setInputLoc("");
      // }
      if (String(value.option.STORE).includes(inputLoc)) {
        setInputLoc("");
      }
    } else if (value.removedValue) {
      let index = 0
      for (var i = 0; i < valLoc.length; i++) {
        if (valLoc[i]["STORE"] === value.removedValue.STORE) {
          index = i;
          break;
        }
      }
      valLoc.splice(index, 1);

    } else if (value.action === "clear") {
      valLoc.splice(0, valLoc.length);
    }
    if (event === 0) {
      valLoc.push(event)
    }
    if (valLoc.length > 0 && typeof valLoc[0]['STORE'] !== "undefined") {
      valLoc.map(
        (item) => {
          selectedLocation.push(item.STORE);
        }
      )
      setSearchData((prev) => {
        return {
          ...prev,
          LOCATION: selectedLocation,
        };
      });
      // }else if(value.length > 0){
      //       swal(
      //         <div>     
      //           <p>{"Please Choose valid LOCATION"}</p>
      //         </div>
      //       )  
      // }
    } else {
      initialsearch.LOCATION = "";
      setSearchData((prev) => {
        return {
          ...prev,
          LOCATION: [],
        };
      });
    }
  }



  const selectLocationlist = (event, value) => {
    //console.log("event:", event)
    //console.log("value:", value)
    setSelectedLocList(event)
    let selectedLocationlist = [];
    if (value.option) {
      valLoc1.push(value.option);
      // if (value.option.LOCATION===parseInt(inputLoc)){ 
      //   //////console.log(1234)
      //   setInputLoc("");
      // }
      if (String(value.option.LOC_LIST).includes(inputLoc1)) {
        setInputLoc("");
      }
    } else if (value.removedValue) {
      let index = 0
      for (var i = 0; i < valLoc.length; i++) {
        if (valLoc1[i]["LOCATIONLIST"] === value.removedValue.LOCATIONLIST) {
          index = i;
          break;
        }
      }
      valLoc1.splice(index, 1);
    } else if (value.action === "clear") {
      valLoc1.splice(0, valLoc1.length);
    }
    if (event === 0) {
      valLoc1.push(event)
    }
    if (valLoc1.length > 0 && typeof valLoc1[0]['LOC_LIST'] !== "undefined") {
      valLoc1.map(
        (item) => {
          selectedLocationlist.push(item.LOC_LIST);
        }
      )
      setSearchData((prev) => {
        return {
          ...prev,
          LOCATIONLIST: selectedLocationlist,
        };
      });
      // }else if(value.length > 0){
      //       swal(
      //         <div>     
      //           <p>{"Please Choose valid LOCATION"}</p>
      //         </div>
      //       )  
      // }
    } else {
      //console.log("clear:")
      initialsearch.LOCATIONLIST = "";
      setSearchData((prev) => {
        return {
          ...prev,
          LOCATIONLIST: [],
        };
      });
    }
  }

  const selectLocationtraits = (event, value) => {
    //console.log("event:", event)
    //console.log("value:", value)
    setSelectedLoctrait(event)
    let selectedLocationtraits = [];
    if (value.option) {
      valLoc2.push(value.option);
      // if (value.option.LOCATION===parseInt(inputLoc)){ 
      //   //////console.log(1234)
      //   setInputLoc("");
      // }
      if (String(value.option.LOC_TRAIT).includes(inputLoc2)) {
        setInputLoc("");
      }
    } else if (value.removedValue) {
      let index = 0
      for (var i = 0; i < valLoc2.length; i++) {
        if (valLoc2[i]["LOCATION_TRAITS"] === value.removedValue.LOCATION_TRAITS) {
          index = i;
          break;
        }
      }
      valLoc2.splice(index, 1);
    } else if (value.action === "clear") {
      valLoc2.splice(0, valLoc2.length);
    }
    if (event === 0) {
      valLoc2.push(event)
    }
    if (valLoc2.length > 0 && typeof valLoc2[0]['LOC_TRAIT'] !== "undefined") {
      valLoc2.map(
        (item) => {
          selectedLocationtraits.push(item.LOC_TRAIT);
        }
      )
      setSearchData((prev) => {
        return {
          ...prev,
          LOCATION_TRAITS: selectedLocationtraits,
        };
      });
      // }else if(value.length > 0){
      //       swal(
      //         <div>     
      //           <p>{"Please Choose valid LOCATION"}</p>
      //         </div>
      //       )  
      // }
    } else {
      //console.log("clear:")
      initialsearch.LOCATION_TRAITS = "";
      setSearchData((prev) => {
        return {
          ...prev,
          LOCATION_TRAITS: [],
        };
      });
    }
  }



  const selectExcludedlocation = (event, value) => {

    //console.log("event:", event)
    //console.log("value:", value)
    setSelectedExcluded(event)
    let selectedExcluded_list = [];
    if (value.option) {
      valLoc3.push(value.option);
      // if (value.option.LOCATION===parseInt(inputLoc)){ 
      //   //////console.log(1234)
      //   setInputLoc("");
      // }
      if (String(value.option.STORE).includes(inputLoc3)) {
        setInputLoc3("");
      }
    } else if (value.removedValue) {
      let index = 0
      for (var i = 0; i < valLoc3.length; i++) {
        if (valLoc3[i]["STORE"] === value.removedValue.STORE) {
          index = i;
          break;
        }
      }
      valLoc3.splice(index, 1);
    } else if (value.action === "clear") {
      valLoc3.splice(0, valLoc3.length);
    }
    if (event === 0) {
      valLoc3.push(event)
    }
    if (valLoc3.length > 0 && typeof valLoc3[0]['STORE'] !== "undefined") {
      valLoc3.map(
        (item) => {
          selectedExcluded_list.push(item.STORE);
        }
      )
      setSearchData((prev) => {
        return {
          ...prev,
          EXCLUDE_LOCATION: selectedExcluded_list,
        };
      });

    } else {
      //console.log("clear:")
      initialsearch.EXCLUDE_LOCATION = "";
      setSearchData((prev) => {
        return {
          ...prev,
          EXCLUDE_LOCATION: [],
        };
      });
    }
  }




  // *******************************************************************************************************************************************************
  // *******************************************************************************************************************************************************

  const addBtnHandler = async () => {
    if (!check1 || (selectedLoc.length || selectedLocList.length || selectedLoctrait.length)) {
      //console.log("searchdatttttt", searchData?.length)
      if (searchData['LOCATION']?.length == 0 || searchData['LOCATION']?.length == "undefined" && searchData['LOCATION_TRAITS']?.length == 0 || searchData['LOCATION_TRAITS']?.length == "undefined" && searchData['LOCATIONLIST']?.length == 0 || searchData['LOCATIONLIST']?.length == "undefined") {
        setTable_data([])
        //console.log("last", searchData)
        setNew_table([])
      }
      setPage(0)
      if (searchData['LOCATION']?.length > 0) {
        let tempdata = [];
        for (let i = 0; i < searchData['LOCATION'].length; i++) {
          tempdata.push(...tableData.filter((ele) => ele['LOCATION'] === searchData['LOCATION'][i]))
        }
        setTable_data(tempdata)
        //console.log("first")
        setNew_table(tempdata.slice(0, 5))
      } else if (searchData['LOCATIONLIST']?.length > 0) {
        let tempdata = [];
        let sub = [];
        for (let i = 0; i < searchData['LOCATIONLIST'].length; i++) {
          //console.log(searchData['LOCATIONLIST'][i])
          let temp = locationList.filter((ele) => (ele['LOC_LIST'] === searchData['LOCATIONLIST'][i]));
          // //console.log(temp)

          for (let j = 0; j < temp.length; j++) {
            sub.push(temp[j]["LOCATION"])
          }
        }
        for (let k = 0; k < sub.length; k++) {
          tempdata.push(...tableData.filter((ele) => ele['LOCATION'] === sub[k]))
        }
        setTable_data(tempdata)
        //console.log("second")
        setNew_table(tempdata.slice(0, 5))
      } else if (searchData['LOCATION_TRAITS']?.length > 0) {
        let tempdata = [];
        let sub = [];
        for (let i = 0; i < searchData['LOCATION_TRAITS'].length; i++) {
          let temp = locationsTraits.filter((ele) => (ele['LOC_TRAIT'] === searchData['LOCATION_TRAITS'][i]));
          for (let j = 0; j < temp.length; j++) {
            sub.push(temp[j]["STORE"])
          }
        }
        for (let k = 0; k < sub.length; k++) {
          tempdata.push(...tableData.filter((ele) => ele['LOCATION'] === sub[k]))
        }
        setTable_data(tempdata)
        //console.log("third")
        setNew_table(tempdata.slice(0, 5))
      } else if (searchData['EXCLUDE_LOCATION']?.length > 0) {
        //console.log("forth" )
      }

      // *******************************************************************************************************************************************************
      // *******************************************************************************************************************************************************

      const data = await axios.post(CONFIG.BASE_URL + `/storeData/`, [searchData])

      let data1 = await data.data.map((res, index) => ({ ...res, id: index + 1 }))
      settableData(data1)
      setRows(data.data)

      setSearchData(searchData)
      console.log("response.data", searchData)


    }
  };


  const deleteRecords = () => {
    console.log(selectedRows);
    const id = selectedRows;

    let updatedTable = tableData.filter((val) => {
      return !selectedRows.includes(val.id)
    });
    console.log("updatedTable:", updatedTable)
    settableData([].concat(updatedTable))
    // setSelectedRows([]);
  };

  // ======================================================================================================================





  // ===========================================================================================================
  const handleClick = () => {

    r1.current.clearValue()
    r2.current.clearValue()
    r3.current.clearValue()
    r4.current.clearValue()

    setCheck1(true)
    setCheck2(true)
    setNew_table([])
    settableData([])
    // window.location.reload(false);

    // setCheck3(true)
    // setCheck4(true)
    // setCheck5(true)
    // setCheck6(true)
    // setCheck7(true)
    // setCheck8(true)



  }


  useEffect(() => {
    (async () => {
      let data = await tableData.filter((res) => selectedRows.includes(res.id))
      setNew_table([].concat(data))
      console.log(data);
    })();
  }, [selectedRows]);

  const handlechange = (e) => {
    const { name, checked } = e.target;
    if (name === "allSelect") {
      let tempuserdata = data.map((ele) => {
        return { ...ele, isChecked: checked };
      });
      setData(tempuserdata);
    } else {
      let tempuserdata = data.map((ele) =>
        ele.Loc == name ? { ...ele, isChecked: checked } : ele
      );
      setData(tempuserdata);
    }
    //console.log("data", data);
  };

  useEffect(() => {

    axios.get(CONFIG.BASE_URL + "/store_tab").then(async (response) => {
      console.log("location:", response);
      setLocations(response.data)
      let arrayObj = await response.data.map(item => {
        return {
          value: item.STORE,
          label: item.STORE
        };
      }

      );
      console.log(arrayObj);
      setLocArray(arrayObj)

    });
    axios.get(CONFIG.BASE_URL + "/store_tab").then(async (response) => {
      console.log("location12345:", response);
      setLocations(response.data)
      let arrayObj1 = await response.data.map(item => {
        return {
          value: item.STORE_DESC,
          label: item.STORE_DESC
        };
      }

      );
      console.log(arrayObj1);
      setLocDescArray(arrayObj1)
    });
    //  http://127.0.0.1:8000/store_traits_tab/
    axios.get(CONFIG.BASE_URL + "/store_traits_tab/").then(async (response) => {
      //console.log(response);
      setLocationTraits(response.data)



    });
    // http://127.0.0.1:8000/store_list_table/
    axios.get(CONFIG.BASE_URL + "/store_list_table/").then((response) => {
      //console.log(response);
      setLocationList(response.data)
    });
    axios.get(CONFIG.BASE_URL + "/status_code_detail_tab/").then(async (response) => {
      //console.log(response);
      setStatus(response.data)
      let arrayObj3 = await response.data.map(item => {
        return {
          value: item.code_desc,
          label: item.code_desc
        };
      }

      );
      console.log(arrayObj3);
      setStatusArray(arrayObj3)

    })
    axios.get(CONFIG.BASE_URL + "/clearance_code_detail_tab/").then(async (response) => {
      //console.log(response);
      setClearance(response.data)
      // console.log("123211",data);
      let arrayObj2 = await response.data.map(item => {
        return {
          value: item.code_desc,
          label: item.code_desc
        };
      }

      );
      console.log(arrayObj2);
      setClearanceArray(arrayObj2)
    })
  }, []);


  //console.log("locationsTraits:", locationsTraits)



  const onClickFile = () => {

  }
  const copyDown = () => {
    console.log(selectedRows);
    const temp = [].concat(tableData);
    let selectedRow = tableData[temp.findIndex(p => p.id == selectedRows[0])]
    //   let updatedData=tableData.forEach((data,index)=>{
    // return data
    //   })
    selectedRows.forEach((data) => {
      let row = temp.filter((res) => res.id == data)
      let index = temp.findIndex(p => p.id == data)
      console.log(selectedRow);
      temp[index] = { ...row[0], LIKE_LOC: selectedRow.LIKE_LOC }
      console.log(temp, index);
      //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
    })
    settableData(temp)
  }

  // const copyDownLikelocDesc=()=>{
  //   console.log(selectedRows);
  //   const temp=[].concat(tableData);
  //   let selectedRow=tableData[temp.findIndex(p=>p.id==selectedRows[0])]
  // //   let updatedData=tableData.forEach((data,index)=>{
  // // return data
  // //   })
  // selectedRows.forEach((data)=>{
  //   let row=temp.filter((res)=>res.id==data)
  //   let index=temp.findIndex(p=>p.id==data)
  //   console.log(selectedRow);
  // temp[index]={...row[0],LIKE_LOC_DESC:selectedRow.LIKE_LOC_DESC,STATUS:selectedRow.STATUS,CLEARANCE_FLAG:selectedRow.CLEARANCE_FLAG,WEIGHT:selectedRow.WEIGHT}
  //    console.log(temp,index);
  //   //  temp[data]={...temp[data],LIKE_LOC:selectedRow.LIKE_LOC}
  // })
  // settableData(temp)}

  const checked = () => {

  }

  // useEffect(() => {
  //   addBtnHandler()
  // }, []);
  const [cellModesModel, setCellModesModel] = React.useState({})

  const handleCellClick = React.useCallback((params) => {
    if (params.isEditable) {
      setCellModesModel(prevModel => {
        return {
          // Revert the mode of the other cells from other rows
          ...Object.keys(prevModel).reduce(
            (acc, id) => ({
              ...acc,
              [id]: Object.keys(prevModel[id]).reduce(
                (acc2, field) => ({
                  ...acc2,
                  [field]: { mode: GridCellModes.View }
                }),
                {}
              )
            }),
            {}
          ),
          [params.id]: {
            // Revert the mode of other cells in the same row
            ...Object.keys(prevModel[params.id] || {}).reduce(
              (acc, field) => ({ ...acc, [field]: { mode: GridCellModes.View } }),
              {}
            ),
            [params.field]: { mode: GridCellModes.Edit }
          }
        }
      })
    }
  }, [])
  const handleCellModesModelChange = React.useCallback(newModel => {
    setCellModesModel(newModel)
  }, [])
  return (
    // <div className="right-container">
    <Box
      component="fieldset"
      display="inline-block"
      sx={{
        backgroundColor: "",
        // height: "auto",
        width: "100%",
        margin: "10px 0px 0px 0px",
        // backgroundColor: "rgb(250, 250, 250)",
        borderRadius: 1,

        boxShadow: 2, border: 0,
        borderBottom: 3,
        border: "1px solid lightgrey",
        // border:"1px dotted gray",
        // borderRadius:"5px",
      }}
    >
      <div>
        <div className="container-headings">Location</div>

        <div className="subcontainer-details-rows">
          <button className="btns">Save Template</button>
          <button className="btns" onClick={handleClick}>REFRESH</button>
          <button className="btns" onClick={HandleAddButton}>ADD</button>
          <button className="btns-delete" onClick={deleteRecords}>Delete</button>
        </div>

        <div className="right-tick-btns">
          <div class="form-check form-switch">
            {/* <input
              class="form-check-input"
              type="checkbox"
              id="flexSwitchCheckDefault"
              onClick={() => {
                handledata_change();
                setCheck1(!check1)
              }} checked={!check1}
            /> */}
            {/* <label class="form-check-label" for="flexSwitchCheckDefault">
              All stores
            </label> */}

            {/* <div className={RulesLocationRightClasses.header_child}> */}
              <FormControlLabel size="small" sx={{ margin: "0px", padding: "0px" }}
                control={
                  <Switch
                    size="small"
                    name="check1"
                    // checked={checked?false:true}
                    onChange={handleswitchcheck}
                    // onClick={() => { setCheck1(!check1) }}
                    inputProps={{ 'aria-label': 'controlled' }}
                  />
                }
                label={<InputLabel
                  sx={{
                    fontWeight: "bold",
                    fontSize: "14px",
                    margin: "0px 0px 0px 0px",
                    padding: "0px 0px 0px 0px",
                    display: 'inline',
                    float: 'left'
                  }}>
                  All stores</InputLabel>}
              />
            {/* </div> */}
          </div>

          <div class="form-check form-switch">
            <input
              class="form-check-input"
              type="checkbox"
              id="flexSwitchCheckDefault"
              onClick={() => { setCheck2(!check2) }} checked={!check2}
            />
            <label class="form-check-label" for="flexSwitchCheckDefault" >
              Enforce Store-WH relationship
            </label>
          </div>
        </div>

        <div className="static-data-row">
          <div className="staic-data-head1">Location Template</div>

          <ReactSelect

            options={[
              { value: "Template Name", label: "Template Name" },
              { value: "option 2", label: "option 2" },
              { value: "option 3", label: "option 3" },
              { value: "option 4", label: "option 4" },
            ]}
            isMulti
            closeMenuOnSelect={false}
            hideSelectedOptions={false}
          />

          <button className="sub-container-btns"
          >Apply</button>
        </div>

        <div className="subcontainer-details-rows">
          <div className="sub-detils-column" >
            <label>Location</label>
            <ReactSelect
              options={locations}
              ref={r1}
              isMulti
              value={selectedLoc}
              onChange={selectLocation}
              // defaultValue={{ value: "Location", label: "Location" }}
              getOptionLabel={option => `${option.STORE.toString()}-${option.STORE_DESC.toString()}`}
              getOptionValue={option => option.STORE}
              closeMenuOnSelect={false}
              hideSelectedOptions={false}
            // valueRenderer={<span>sdfds</span>}
            />
          </div>

          <div className="sub-detils-column" >
            <label>Location List</label>
            <ReactSelect
              options={locationList}
              ref={r2}
              isMulti
              value={selectedLocList}
              onChange={selectLocationlist}
              //defaultValue={{ value: "Location List", label: "Location List" }}
              getOptionLabel={option => option.LOC_LIST_DESC}
              getOptionValue={option => option.LOC_LIST}
              closeMenuOnSelect={false}
              hideSelectedOptions={false}
            />
          </div>

          <div className="sub-detils-column" >
            <label>Location Traits</label>
            <ReactSelect
              options={locationsTraits}
              ref={r3} isMulti
              value={selectedLoctrait}
              onChange={selectLocationtraits}
              getOptionLabel={option => `${option.LOC_TRAIT.toString()}-${option.TRAIT_DESC.toString()}`}
              getOptionValue={option => option.LOC_TRAIT}
              closeMenuOnSelect={false}
              hideSelectedOptions={false}

            />
          </div>

          <div className="sub-detils-column" >
            <label> Exclude Location</label>
            <ReactSelect

              options={locations}
              onChange={selectExcludedlocation}
              ref={r4}
              isMulti
              value={selectedExcluded}
              // defaultValue={{ value: "Location", label: "Location" }}
              getOptionLabel={option => `${option.STORE.toString()}-${option.STORE_DESC.toString()}`}
              getOptionValue={option => option.STORE}
              closeMenuOnSelect={false}
              hideSelectedOptions={false}
            />

          </div>
        </div>

        <div id="table-div-ele" >
          <div style={{ height: 400, width: "100%" }} >
            <DataGrid

              rows={tableData}
              columns={columns}
              pageSize={5}
              rowsPerPageOptions={[5]}
              onCellModesModelChange={handleCellModesModelChange}
              onCellClick={handleCellClick}
              cellModesModel={cellModesModel}
              checkboxSelection
              onCellEditCommit={(props, event) => {
                tableData[props.id - 1][props.field] = props.value;
                settableData((tableData) => [].concat(tableData))
              }}
              onSelectionModelChange={(newSelection) => {
                console.log(newSelection);
                setSelectedRows([].concat(newSelection));
                // setSelectedRows(newSelection)
              }}
              disableSelectionOnClick={true}

            />
          </div>
        </div>
      </div>
    </Box>
  );
};

export default RightContainer;







