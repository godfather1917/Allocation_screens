import "./Left.css"
import React, { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import Select from 'react-select';
import axios from "axios";
import { CONFIG } from "../../services/config";
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Typography from '@mui/material/Typography';
import PropTypes from 'prop-types';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import { Box } from "@mui/system";
import { DataGrid, GridCellParams, GridCellModes, GridCellModesModel } from "@mui/x-data-grid";
// import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import TextField from "@mui/material/TextField";
import InputLabel from '@mui/material/InputLabel';
import { makeStyles, withStyles } from "@mui/styles";
import Button from "@mui/material/Button";
import Switch from '@mui/material/Switch';
// import FormControlLabel from '@mui/material/FormControlLabel';
import { FormControlLabel } from '@material-ui/core';
import makeAnimated from 'react-select/animated';
import Checkbox from '@mui/material/Checkbox';
import {
    getRULESTYPERequest,
    getNEEDTYPERequest,
    getHIERARCHYTYPERequest,
    getALLOCATETOTYPERequest,
} from "../../Redux/Action/rules&location";




const BootstrapDialog = styled(Dialog)(({ theme }) => ({
    '& .MuiDialogContent-root': {
        padding: theme.spacing(2),
    },
    '& .MuiDialogActions-root': {
        padding: theme.spacing(1),
    },
}));

function BootstrapDialogTitle(props) {
    const { children, onClose, ...other } = props;

    return (
        <DialogTitle sx={{ m: 0, p: 2 }} {...other}>
            {children}
            {onClose ? (
                <IconButton
                    aria-label="close"
                    onClick={onClose}
                    sx={{
                        position: 'absolute',
                        right: 8,
                        top: 8,
                        color: (theme) => theme.palette.grey[500],
                    }}
                >
                    <CloseIcon />
                </IconButton>
            ) : null}
        </DialogTitle>
    );
}

BootstrapDialogTitle.propTypes = {
    children: PropTypes.node,
    onClose: PropTypes.func.isRequired,
};


const columns = [

    {
        field: "EOW",
        headerName: "EOW",
        width: 150,
    },


    {
        field: "WEIGHT",
        headerName: "WEIGHT %",
        description: "This column has a value getter and is not sortable.",
        editable: true,

        width: 150,
        //   renderHeader:likeWeightAction
    },

];
// const initialInd={
//     RULE_LEVEL: "",
//     EXACT_IND: "", 
//     RULE_TYPE: "", 
//     NET_NEED_IND: "", 
//     REGULAR_SALES_IND: "",
//     PROMO_SALES_IND: "", 
//     CLEARANCE_SALES_IND: "",
//     USESIZEPROFILE: "", 
//     DEFAULTAUTOPRESENTATIONMINANDQTYLIMITS: "", 
//     START_DATE1: "", 
//     END_DATE1: "", 
//     START_DATE2: "", 
//     END_DATE2: "", 
//     WEEKS_THIS_YEAR: "", 
//     WEEKS_LAST_YEAR: "", 
//     ON_ORDER_COMMIT_WEEKS: "", 
//     ON_ORDER_COMMIT_DATE: "", 
// }

const useStyles = makeStyles({
    maindiv: {
        position: "relative",
        // backgroundColor:"yellow",
        // width:"100%",
        width: "calc(95vw - 0px)",
        "& table": {
            "& tr": {
                "& td:nth-child(29)": {
                    display: "none",
                },
                "& td:nth-child(30)": {
                    display: "none",
                },
                "& td:nth-child(31)": {
                    display: "none",
                },
            },
        },
    },
    boxDiv: {
        textAlign: "initial",
        position: "relative",
        maxWidth: "1400px",
        // backgroundColor:"yellow"
    },
    // uploaddiv: {
    //     display: "flex",
    //     alignItems: "center",
    //     marginTop: "50px",
    //     textAlign: "start",
    //     gap: 20,
    //     // backgroundColor:"lightgreen"
    // },
    TitleHead: {
        // height: "25px",
        position: "sticky",
        top: -1,
    },
    GobackDiv: {
        cursor: "pointer",
    },
    textField: {
        marginRight: "10px !important",
    },
    dateField: {
        "& .MuiInput-input": {
            color: "rgba(102,102,102,1)",
        },
    },
    popUp: {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: 400,
        backgroundColor: "white",
        border: "2px solid #000",
        boxShadow: 24,
        padding: "20px 20px 20px 20px",
    },
    header_container: {
        display: "inline-block",
        // marginTop: "0.2rem",
        // padding: "1rem 1rem",
        // text-align: center;
    },
    header_child: {
        display: "inline-block",
        // border: "1px solid red",
        padding: "0rem 0.2rem",
        verticalAlign: "middle",
    },
    input: {
        // width: "250px",
        height: 37.8,
        // backgroundColor:"#f0f0f0",
        '& input + fieldset': {
            // borderColor: 'gray',
            borderRadius: "0",
            boxShadow: "rgba(0, 0, 0, 0.19) 0px 1px 2px, rgba(0, 0, 0, 0.23) 0px 2px 2px"
        },
    },
    divBoxLeft: {
        width: "50%",
        float: "left"
    },
    divBoxRight: {
        marginLeft: "50%",
    },
    uploaddiv: {
        display: "flex",
        alignItems: "center",
        marginTop: "20px",
        textAlign: "start",
        gap: 10,
    },
    float_container: {
        display: "inline-block",
        margin: "0rem 0.3rem",
        // padding: "1rem 1rem",
        // text-align: center;
    },
    container_child: {
        float: "left"
    },
    multiselectfield: {
        display: "inline-block",
        // border: "1px solid red",
        margin: "0rem",
        padding: "0rem 0rem",
        verticalAlign: "middle",
    },
    input: {
        // width: "250px",
        height: 37.8,
        // backgroundColor:"#f0f0f0",
        '& input + fieldset': {
            // borderColor: 'gray',
            borderRadius: "0",
            boxShadow: "rgba(0, 0, 0, 0.19) 0px 1px 2px, rgba(0, 0, 0, 0.23) 0px 2px 2px"
        },
    },
    divHeight: {
        // flex: 1,
        padding: "0.2em",
        float: "left",
        minHeight: "100%",
    },
    divHeightMain: {
        display: "flex",
        alignItems: "stretch",
        justifyContent: "space-around"
    },
})

const styleSelect1 = {
    control: base => ({
        ...base,
        width: "200px",
        fontSize: "14px",
        margin: "0px 0px 0px 0px",
        // This line disable the blue border
        borderRadius: "0",
        // backgroundColor:"#f0f0f0",
        //border:"1px solid red",
        boxShadow: "rgba(0, 0, 0, 0.19) 0px 1px 2px, rgba(0, 0, 0, 0.23) 0px 2px 2px",
        // (isValid && searchHeaderData.CONTEXT.length===0)
        // '& input + fieldset': {
        //   // borderColor: 'gray',
        //   // borderRadius:"0",
        //   // boxShadow:"rgba(0, 0, 0, 0.19) 0px 1px 2px, rgba(0, 0, 0, 0.23) 0px 2px 2px"
        // },
    })
    ,
    dropdownIndicator: (base) => ({
        ...base,
        paddingTop: 0,
        paddingBottom: 0,
    }),
    clearIndicator: (base) => ({
        ...base,
        paddingTop: 0,
        paddingBottom: 0,
    }),
    valueContainer: (provided) => ({
        ...provided,
        // minHeight: '1px',
        height: '30px',
        paddingTop: '0',
        paddingBottom: '0',
    }),
    singleValue: (provided) => ({
        ...provided,
        // minHeight: '1px',
        // paddingBottom: '0px',

    }),
    input: (provided) => ({
        ...provided,
        width: "100%",
        // minHeight: '1px',
    }),
    option: provided => ({
        ...provided,
        // color: 'blue',
        fontSize: "12px",
    }),
    menu: base => ({
        ...base,
        // override border radius to match the box
        borderRadius: 0,
        // backgroundColor: 'black',
        // kill the gap
        marginTop: 0
    }),
    menuList: base => ({
        ...base,
        // kill the white space on first and last option
        padding: 0
    })
};

const animatedComponents = makeAnimated();

const optionsTemplates = [
    { value: "Template Name", label: "Template Name" },
    { value: "option 2", label: "option 2" },
    { value: "option 3", label: "option 3" },
    { value: "option 4", label: "option 4" }
]


const LeftContainer = forwardRef(({ setSubmit, setLeftContData, ref, allocLevel, allocNoData, allocDetails }) => {
    const [ruleType, setRuleType] = useState([]);
    // const [showDates, setShowDates] = useState(false);
    const [Hierarchy, setHierarchy] = useState([]);
    const [Need, setNeed] = useState([]);
    const [Allocateto, setAllocateto] = useState([]);
    const [ruleType1, setRuleType1] = useState([]);
    // const [showDates, setShowDates] = useState(false);
    const [Hierarchy1, setHierarchy1] = useState([]);
    const [Need1, setNeed1] = useState([]);
    const [Allocateto1, setAllocateto1] = useState([]);
    const [check1, setCheck1] = useState(true)
    const [check2, setCheck2] = useState(false)
    const [check3, setCheck3] = useState(false)
    const [check4, setCheck4] = useState(false)
    const [check5, setCheck5] = useState(false)
    const [check6, setCheck6] = useState(false)
    const [check7, setCheck7] = useState(false)
    const [check8, setCheck8] = useState(false)
    const [check9, setCheck9] = useState(false)
    const [promotion, setPromotion] = useState(true)
    const [changeWeights, setChangeWeights] = useState([])

    // ****** DATE RANGE ***** //
    const [thisY, setThisY] = useState("")    
    const [lastY, setLastY] = useState("")    

    const [strt1, setStrt1] = useState("")
    const [strt2, setStrt2] = useState("")   
    const [end1, setEnd1] = useState("") 
    const [end2, setEnd2] = useState("") 
    // ****** include inventory ******* //
    const [weekNo, setWeekNo] = useState("")    
    const [finalD, setFinalD] = useState("") 
    // const[ruleType,setRuleType]=useState();
    //for createalloc screen dailog
    // const [createAlloc,setCreateAlloc]=useState([])

    const [inputchange, setInputChange] = useState([])
    const r1 = useRef()
    const r2 = useRef()
    const r3 = useRef()
    const r4 = useRef()
    const r5 = useRef()
    const firstRef = useRef()
    const secondtRef = useRef()
    const thirdRef = useRef()
    const fourthRef = useRef()
    const fifthRef = useRef()
    const sixthRef = useRef()
    const seventhref = useRef()
    const eighthref = useRef()
    const ninthref = useRef()
    const tenthref = useRef()
    //To show and hide dialog
    const [open, setOpen] = React.useState(false);
    //to show a changeweight dialog box
    const [openDialog, setOpenDialog] = React.useState(false);

    const [loading, setLoading] = useState(false);
    const [isSearch, setSearch] = useState(false);

    const RulesLocationLeftClasses = useStyles();

    const RulesLocationLeftData = useSelector(
        (state) => state.RulesLocationReducers
    );

    const dispatch = useDispatch();

    useEffect(() => {
        setLoading(true);
        dispatch(getRULESTYPERequest([{}]));
        dispatch(getNEEDTYPERequest([{}]));
        dispatch(getHIERARCHYTYPERequest([{}]));
        dispatch(getALLOCATETOTYPERequest([{}]));
    }, [""]);

    useEffect(() => {
        if (
            RulesLocationLeftData?.data?.ruleType
            && Array.isArray(RulesLocationLeftData?.data?.ruleType)
        ) {
            setRuleType(RulesLocationLeftData?.data?.ruleType);
            setLoading(false);
        } else if (
            RulesLocationLeftData?.data?.Need
            && Array.isArray(RulesLocationLeftData?.data?.Need)
        ) {
            setNeed(RulesLocationLeftData?.data?.Need);
            setLoading(false);
        } else if (
            RulesLocationLeftData?.data?.Hierarchy
            && Array.isArray(RulesLocationLeftData?.data?.Hierarchy)
        ) {
            setHierarchy(RulesLocationLeftData?.data?.Hierarchy);
            setLoading(false);
        } else if (
            RulesLocationLeftData?.data?.Allocateto
            && Array.isArray(RulesLocationLeftData?.data?.Allocateto)
        ) {
            setAllocateto(RulesLocationLeftData?.data?.Allocateto);
            setLoading(false);
        } else {
            setSearch(false);
        }
    }, [RulesLocationLeftData?.data]);

    const [checked, setChecked] = React.useState(false);

    // console.log("ruleType::", Hierarchy1, Allocateto1, ruleType1);

    //To open dialog
    const handleClickOpen = () => {
        setOpen(true);
    };

    const handleClose = () => {
        setOpen(false);
    };
    //to open dialogfor changeweights
    const handleClickOpen1 = () => {
        axios.post(CONFIG.BASE_URL + "/Alloc_change_weights_tab/", [{ "ALLOC_NO": "1234" }]).then(async (response) => {
            console.log(response);
            let data = await response.data.map((res, index) => ({ ...res, id: index + 1 }))
            setChangeWeights(data)
        });
        setOpenDialog(true);
    };

    const handleClose1 = () => {
        console.log("fdfdg");
        setOpenDialog(false);
    }

    // const r1 = useRef()
    // useEffect(() => {
    //     console.log("LeftContData",LeftContData);
    // }, [LeftContData]);
    useImperativeHandle(ref, () => ({
        handleClick1() {
            setLeftContData({
                RULE_LEVEL: Hierarchy1,
                EXACT_IND: Need1,
                RULE_TYPE: ruleType1,
                NET_NEED_IND: Allocateto1,
                REGULAR_SALES_IND: check1 ? 'Y' : 'N',
                PROMO_SALES_IND: check2 ? 'N' : 'Y',
                CLEARANCE_SALES_IND: check3 ? 'N' : 'Y',
                USESIZEPROFILE: check4 ? 'N' : 'Y',
                DEFAULTAUTOPRESENTATIONMINANDQTYLIMITS: check5 ? 'N' : 'Y',
                START_DATE1: firstRef.current ? firstRef.current.value : "",
                END_DATE1: secondtRef.current ? secondtRef.current.value : "",
                START_DATE2: thirdRef.current ? thirdRef.current.value : "",
                END_DATE2: fourthRef.current ? fourthRef.current.value : "",
                WEEKS_THIS_YEAR: sixthRef.current ? sixthRef.current.value : "",
                WEEKS_LAST_YEAR: seventhref.current ? seventhref.current.value : "",
                ON_ORDER_COMMIT_WEEKS: eighthref.current ? eighthref.current.value : "",
                ON_ORDER_COMMIT_DATE: fifthRef.current ? fifthRef.current.value : ""
            })
        }
    }))
    useEffect(() => {
        setLeftContData({
            RULE_LEVEL: Hierarchy1,
            EXACT_IND: Need1,
            RULE_TYPE: ruleType1,
            NET_NEED_IND: Allocateto1,
            REGULAR_SALES_IND: check1 ? 'Y' : 'N',
            PROMO_SALES_IND: check2 ? 'N' : 'Y',
            CLEARANCE_SALES_IND: check3 ? 'N' : 'Y',
            USESIZEPROFILE: check4 ? 'N' : 'Y',
            DEFAULTAUTOPRESENTATIONMINANDQTYLIMITS: check5 ? 'N' : 'Y',
            START_DATE1: firstRef.current?.value,
            END_DATE1: secondtRef.current?.value,
            START_DATE2: thirdRef.current?.value,
            END_DATE2: fourthRef.current?.value,
            WEEKS_THIS_YEAR: sixthRef.current?.value,
            WEEKS_LAST_YEAR: seventhref.current?.value,
            ON_ORDER_COMMIT_WEEKS: eighthref.current?.value,
            ON_ORDER_COMMIT_DATE: fifthRef.current?.value
        })
    }, [ruleType1, Hierarchy1, Need1, Allocateto1, check2, check1, check3, check4, check5])

    const handleClick = (e) => {


        r1.current.clearValue()
        r2.current.clearValue()
        r3.current.clearValue()
        r4.current.clearValue()
        setCheck1(true)
        setCheck2(true)
        setCheck3(true)
        setCheck4(true)
        setCheck5(true)
        setCheck6(true)
        setCheck7(true)
        setCheck8(true)
        setCheck9(true)
        //  setShowDates(false);
        //  window.location.reload(false);

    }

    const handleswitchcheck = (e, val) => {
        console.log("e::", e, val, e.target.name)
        if (e.target.name === "check1") {
            setCheck1(val)
        }
        if (e.target.name === "check2") {
            setCheck2(val)
        }
        if (e.target.name === "check3") {
            setCheck3(val)
        }
        if (e.target.name === "check4") {
            setCheck4(val)
        }
        if (e.target.name === "check5") {
            setCheck5(val)
        }
        if (e.target.name === "check6") {
            console.log(123456)
            setCheck6(true);
            setCheck9(false);
        }
        if (e.target.name === "check7") {
            setCheck7(val)
            // setCheck8(!val)
        }
        if (e.target.name === "check8") {
            setCheck8(val)
            // setCheck7(!val)
        }
        if (e.target.name === "check9") {
            setCheck9(true)
           
        }

    }

    /////////////////////////////
    /////////////////////
    ////////////////////////////////
    const selectRuleType = (val) => {
        // console.log("value,e", val)
        if (val) {
            setRuleType1((prev) => {
                return [{
                    ...prev,
                    RULE_TYPE: val.CODE_DESC
                }];
            });
        }
        else {
            setRuleType1((prev) => {
                return [{
                    ...prev,
                    RULE_TYPE: ""
                }];
            });
        }
    }

    const selectNEEDType = (val) => {
        // console.log("value,e", val)
        if (val) {
            if (val.CODE_DESC === "Proportional") {
                setNeed1((prev) => {
                    return [{
                        ...prev,
                        NEED: "N"
                    }];
                });
            }
            else if (val.CODE_DESC === "Exact") {
                setNeed1((prev) => {
                    return [{
                        ...prev,
                        NEED: "Y"
                    }];
                });
            }
        }
        else {
            setNeed1((prev) => {
                return [{
                    ...prev,
                    NEED: ""
                }];
            });
        }
    }

    const selectHierarchy = (val) => {
        // console.log("value,e", val)
        if (val) {
            setHierarchy1((prev) => {
                return [{
                    ...prev,
                    HIERARCHY: val.CODE_DESC
                }];
            });
        }
        else {
            setHierarchy1((prev) => {
                return [{
                    ...prev,
                    HIERARCHY: ""
                }];
            });
        }
    }

    const selectAllocateTo = (val) => {
        // console.log("value,e", val)
        if (val) {
            if (val.CODE_DESC === "Net Need") {
                setAllocateto1((prev) => {
                    return [{
                        ...prev,
                        ALLOCATETO: "N"
                    }];
                });
            }
            else if (val.CODE_DESC === "Gross Need") {
                setAllocateto1((prev) => {
                    return [{
                        ...prev,
                        ALLOCATETO: "Y"
                    }];
                });
            }
        }
        else {
            setAllocateto1((prev) => {
                return [{
                    ...prev,
                    ALLOCATETO: ""
                }];
            });
        }
    }


    // input variable to save input dropdowns
    const handleInput = (e, key) => {

        // setInputChange(...e)
        // setSubmit(...e)
        console.log("input:", key, e[0].code_desc);

    }

    const handlesubmit = (e) => {
        const submit_data = inputchange
    }


    const [cellModesModel, setCellModesModel] = React.useState({})
    const handleCellClick = React.useCallback((params) => {
        if (params.isEditable) {
            setCellModesModel(prevModel => {
                return {
                    // Revert the mode of the other cells from other rows
                    ...Object.keys(prevModel).reduce(
                        (acc, id) => ({
                            ...acc,
                            [id]: Object.keys(prevModel[id]).reduce(
                                (acc2, field) => ({
                                    ...acc2,
                                    [field]: { mode: GridCellModes.View }
                                }),
                                {}
                            )
                        }),
                        {}
                    ),
                    [params.id]: {
                        // Revert the mode of other cells in the same row
                        ...Object.keys(prevModel[params.id] || {}).reduce(
                            (acc, field) => ({ ...acc, [field]: { mode: GridCellModes.View } }),
                            {}
                        ),
                        [params.field]: { mode: GridCellModes.Edit }
                    }
                }
            })
        }
    }, [])
    const handleCellModesModelChange = React.useCallback(newModel => {
        setCellModesModel(newModel)
    }, [])



    const rangeWeek1= (event) => {
        setThisY(event.target.value)
    }
    const rangeWeek2= (event) => {
        setLastY(event.target.value);
    }

    const startEnd1 = (event) => {
        setStrt1(event.target.value)
    }
    const startEnd2 = (event) => {
        setStrt2(event.target.value);
    }
    const startEnd3 = (event) => {
        setEnd1(event.target.value);
    }
    const startEnd4 = (event) => {
        setEnd2(event.target.value);
    } 


    //setLeftContData((prev)=>{console.log("leftcont Data -- ",prev)})
    console.log(23456,thisY,lastY,strt1,end1,"inv",weekNo,finalD)
    const Inventory_Range = () => (
        <div className={RulesLocationLeftClasses.header_child}>
            <Box
                display="flex"
                sx={{
                    width: "100%"
                }}
            >
                <div className={RulesLocationLeftClasses.divHeightMain}>
                    <div className={RulesLocationLeftClasses.divHeight}>
                        <Box
                            component="fieldset"
                            display="inline-block"
                            sx={{
                                backgroundColor: "",
                                height: "100%",
                                width: "100%",
                                margin: "10px 0px 0px 0px",
                                // backgroundColor: "rgb(250, 250, 250)",
                                borderRadius: 1,

                                boxShadow: 2, border: 0,
                                borderBottom: 3,
                                border: "1px solid lightgrey",
                                // border:"1px dotted gray",
                                // borderRadius:"5px",
                            }}
                        >
                            <legend style={{ fontWeight: "bold", color: "#191970", }}>Date Range</legend>
                            <div>
                                <FormControlLabel control={
                                    <Checkbox
                                    checked={check6}
                                        name="check6"
                                        // onChange={handleswitchcheck}
                                        onChange={(event)=>{ 
                                            setCheck9(false)
                                            setCheck6(event.target.checked)
                                            if(!check6){
                                                setStrt1("");
                                                setStrt2("");
                                                setEnd1("");
                                                setEnd2("");
                                            }
                                        }}                                    
                                    />
                                } label="Weeks from Today" />
                            </div>
                            {check6 ?
                                <div>
                                    <div className={RulesLocationLeftClasses.header_child}>
                                        <InputLabel sx={{ fontWeight: "", fontSize: "14px", margin: "2px 5px 0px 2px", display: 'flex', float: 'left' }}>
                                            TY: </InputLabel>
                                        <TextField
                                            type="number"
                                            // value={values.numberformat}
                                            onChange={rangeWeek1}
                                            //onChange={(event)=>{setThisY(event.target.value)}}
                                            sx={{ width: "50px" }}
                                            name="TY"
                                            id="formatted-numberformat-input"
                                            InputProps={{
                                                style: { fontSize: 12, height: "25px" },
                                            }}
                                            variant="standard"
                                        />
                                    </div>

                                    <div className={RulesLocationLeftClasses.header_child}>
                                        <InputLabel sx={{ fontWeight: "", fontSize: "14px", margin: "2px 5px 0px 2px", display: 'flex', float: 'left' }}>
                                            LY: </InputLabel>
                                        <TextField
                                            type="number"
                                            sx={{ width: "50px" }}
                                            // value={values.numberformat}
                                            onChange={rangeWeek2}
                                            //onChange={(event)=>{setLastY(event.target.value)}}
                                            name="LY"
                                            id="formatted-numberformat-input"
                                            InputProps={{
                                                style: { fontSize: 12, height: "25px" },
                                            }}
                                            variant="standard"
                                        />

                                    </div>
                                </div>
                                : null}

                            <div>
                                <Button
                                    sx={{
                                        fontSize: "12px",
                                        margin: "10px 0px 0px 0px",
                                    }}
                                    onClick={handleClick}
                                    variant="contained">
                                    Change Weights
                                </Button>
                            </div>

                            <div>
                                <FormControlLabel control={
                                    <Checkbox
                                    checked={check9}
                                        name="check9"
                                        //onChange={handleswitchcheck}
                                        onChange={(event)=>{ setCheck6(false);
                                            setCheck9(event.target.checked);
                                            if(!check9){
                                                setThisY("");
                                                setLastY("");
                                            }
                                        }}
                                    />
                                } label="Start/End Dates" /> 
                                
                            </div>

                            {check9 ?
                                <div>
                                    <div className={RulesLocationLeftClasses.header_child}>
                                        <div>
                                            <InputLabel sx={{ fontWeight: "", fontSize: "14px", margin: "2px 5px 0px 2px", display: 'flex', float: 'left' }}>
                                                Start: </InputLabel>
                                        </div>

                                        <div >
                                            <TextField
                                                variant="outlined"
                                                type="date"
                                                size="small"
                                                name="1st"
                                                format="yyyy/MM/dd"
                                                //   inputProps={{ max: currentDate() }}
                                                sx={{
                                                    margin: "0px 0px 10px 2px", width: "120px"
                                                    , "& .MuiInputBase-input.Mui-disabled": {
                                                        backgroundColor: "#f0f0f0"
                                                    }
                                                }}
                                                id="outlined-disabled"
                                                label=""
                                                // value={allocDetails[0].RELEASE_DATE}
                                                // defaultValue={allocDetails[0].RELEASE_DATE}
                                                InputProps={{
                                                    style: { fontSize: 12 },
                                                    shrink: true,
                                                    className: RulesLocationLeftClasses.input,
                                                }}
                                                onChange={startEnd1}
                                            />
                                        </div>

                                        <div >
                                            <TextField
                                                variant="outlined"
                                                type="date"
                                                size="small"
                                                name="1st"
                                                format="yyyy/MM/dd"
                                                //   inputProps={{ max: currentDate() }}
                                                sx={{
                                                    margin: "0px 0px 10px 2px", width: "120px"
                                                    , "& .MuiInputBase-input.Mui-disabled": {
                                                        backgroundColor: "#f0f0f0"
                                                    }
                                                }}
                                                id="outlined-disabled"
                                                label=""
                                                // value={allocDetails[0].RELEASE_DATE}
                                                // defaultValue={allocDetails[0].RELEASE_DATE}
                                                InputProps={{
                                                    style: { fontSize: 12 },
                                                    shrink: true,
                                                    className: RulesLocationLeftClasses.input,
                                                }}
                                                onChange={startEnd2}

                                            />

                                        </div>
                                    </div>


                                    <div className={RulesLocationLeftClasses.header_child}>
                                        <div>
                                            <InputLabel sx={{ fontWeight: "", fontSize: "14px", margin: "2px 5px 0px 2px", display: 'flex', float: 'left' }}>
                                                End: </InputLabel>
                                        </div>

                                        <div >
                                            <TextField
                                                variant="outlined"
                                                type="date"
                                                size="small"
                                                name="1st"
                                                format="yyyy/MM/dd"
                                                //   inputProps={{ max: currentDate() }}
                                                sx={{
                                                    margin: "0px 0px 10px 2px", width: "120px"
                                                    , "& .MuiInputBase-input.Mui-disabled": {
                                                        backgroundColor: "#f0f0f0"
                                                    }
                                                }}
                                                id="outlined-disabled"
                                                label=""
                                                // value={allocDetails[0].RELEASE_DATE}
                                                // defaultValue={allocDetails[0].RELEASE_DATE}
                                                InputProps={{
                                                    style: { fontSize: 12 },
                                                    shrink: true,
                                                    className: RulesLocationLeftClasses.input,
                                                }}
                                                onChange={startEnd3}

                                            />
                                        </div>

                                        <div >
                                            <TextField
                                                variant="outlined"
                                                type="date"
                                                size="small"
                                                name="1st"
                                                format="yyyy/MM/dd"
                                                //   inputProps={{ max: currentDate() }}
                                                sx={{
                                                    margin: "0px 0px 10px 2px", width: "120px"
                                                    , "& .MuiInputBase-input.Mui-disabled": {
                                                        backgroundColor: "#f0f0f0"
                                                    }
                                                }}
                                                id="outlined-disabled"
                                                label=""
                                                // value={allocDetails[0].RELEASE_DATE}
                                                // defaultValue={allocDetails[0].RELEASE_DATE}
                                                InputProps={{
                                                    style: { fontSize: 12 },
                                                    shrink: true,
                                                    className: RulesLocationLeftClasses.input,
                                                }}
                                                onChange={startEnd4}

                                            />

                                        </div>
                                    </div>
                                </div>
                                : null}
                        </Box>
                    </div>

                    <div className={RulesLocationLeftClasses.divHeight}>
                        <Box
                            component="fieldset"
                            display="inline-block"
                            sx={{
                                backgroundColor: "",
                                height: "100%",
                                width: "100%",
                                margin: "10px 0px 0px 0px",
                                // backgroundColor: "rgb(250, 250, 250)",
                                borderRadius: 1,

                                boxShadow: 2, border: 0,
                                borderBottom: 3,
                                border: "1px solid lightgrey",
                                // border:"1px dotted gray",
                                // borderRadius:"5px",
                            }}
                        >
                            <legend style={{ fontWeight: "bold", color: "#191970", }}>Include Inventory</legend>
                            <div>
                                <FormControlLabel control={
                                    <Checkbox
                                    checked={check7}
                                        name="check7"
                                        //onChange={handleswitchcheck}
                                        onChange={(event)=>{ setCheck8(false);
                                            setCheck7(event.target.checked);
                                            setFinalD("");
                                        }}
                                    />
                                } label="Weeks from Today" />
                            </div>

                            {check7 ?
                                <div>
                                    <InputLabel sx={{ fontWeight: "", fontSize: "14px", margin: "2px 5px 0px 2px", display: 'flex', float: 'left' }}>
                                        WEEKS NO: </InputLabel>
                                    <TextField
                                        type="number"
                                        // value={values.numberformat}
                                        // onChange={handleChange}
                                        sx={{ width: "50px" }}
                                        // name="TY"
                                        id="formatted-numberformat-input"
                                        InputProps={{
                                            style: { fontSize: 12, height: "25px" },
                                        }}
                                        variant="standard"
                                        onChange={(event)=>{setWeekNo(event.target.value)}}
                                    />
                                </div>
                                : null}

                            <div>
                                <FormControlLabel control={
                                    <Checkbox
                                    checked={check8}
                                        name="check8"
                                        //onChange={handleswitchcheck}
                                        onChange={(event)=>{ setCheck7(false);
                                            setCheck8(event.target.checked);
                                            setWeekNo("");
                                        }}
                                    />
                                } label="On Order Commit Date" />
                            </div>

                            {check8 ?
                                <div>
                                    <div>
                                        <InputLabel sx={{ fontWeight: "", fontSize: "14px", margin: "2px 5px 0px 2px", display: 'flex', float: 'left' }}>
                                            Final Date: </InputLabel>
                                    </div>

                                    <div>
                                        <TextField
                                            variant="outlined"
                                            type="date"
                                            size="small"
                                            name="1st"
                                            format="yyyy/MM/dd"
                                            //   inputProps={{ max: currentDate() }}
                                            sx={{
                                                margin: "0px 0px 10px 2px", width: "120px"
                                                , "& .MuiInputBase-input.Mui-disabled": {
                                                    backgroundColor: "#f0f0f0"
                                                }
                                            }}
                                            id="outlined-disabled"
                                            label=""
                                            // value={allocDetails[0].RELEASE_DATE}
                                            // defaultValue={allocDetails[0].RELEASE_DATE}
                                            InputProps={{
                                                style: { fontSize: 12 },
                                                shrink: true,
                                                className: RulesLocationLeftClasses.input,
                                            }}
                                            onChange={(event)=>{setFinalD(event.target.value)}}
                                        />
                                    </div>
                                </div>
                                : null}

                        </Box>
                    </div>
                </div>
            </Box>
        </div>

    )

    return (
        // <div className={RulesLocationLeftClasses.divBoxLeft}>
        <Box
            component="fieldset"
            display="inline-block"
            sx={{
                backgroundColor: "",
                height: "auto",
                width: "100%",
                margin: "10px 0px 0px 0px",
                // backgroundColor: "rgb(250, 250, 250)",
                borderRadius: 1,

                boxShadow: 2, border: 0,
                borderBottom: 3,
                border: "1px solid lightgrey",
                // border:"1px dotted gray",
                // borderRadius:"5px",
            }}
        >
            <div className={RulesLocationLeftClasses.header_container}>
                <div className={RulesLocationLeftClasses.header_child}>
                    <InputLabel sx={{ fontWeight: "bold", fontSize: "18px", margin: "2px 0px -5px 2px", display: 'flex', float: 'left' }}>
                        Rules & History Range</InputLabel>
                </div>
                <div>
                    <div className={RulesLocationLeftClasses.header_child}>
                        <Button
                            sx={{
                                fontSize: "12px",
                                margin: "10px 0px 0px 0px",
                            }}
                            onClick={handleClickOpen1}
                            variant="contained">
                            Refresh
                        </Button>
                    </div>
                    <div className={RulesLocationLeftClasses.header_child}>
                        <Button
                            sx={{
                                fontSize: "12px",
                                margin: "10px 0px 0px 0px",
                            }}
                            variant="contained">
                            Save Template
                        </Button>
                    </div>
                </div>

                <div>
                    {(ruleType1.length > 0 ? ruleType1[0].RULE_TYPE === 'Forecast' : null) ? null :
                        <div>
                            <div className={RulesLocationLeftClasses.header_child}>
                                <InputLabel sx={{ fontWeight: "bold", fontSize: "18px", margin: "12px 0px 2px 2px", display: 'flex', float: 'left' }}>
                                    Sales history Types :</InputLabel>
                            </div>
                            <div>
                                <div className={RulesLocationLeftClasses.header_child}>
                                    <FormControlLabel size="small" sx={{ margin: "0px", padding: "0px" }}
                                        control={
                                            <Switch
                                                size="small"
                                                name="check1"
                                                defaultChecked
                                                // checked={checked?true:false}
                                                onChange={handleswitchcheck}
                                                // onClick={() => { setCheck1(!check1) }}
                                                inputProps={{ 'aria-label': 'controlled' }}
                                            />
                                        }
                                        label={<InputLabel
                                            sx={{
                                                fontWeight: "bold",
                                                fontSize: "14px",
                                                margin: "0px 0px 0px 0px",
                                                padding: "0px 0px 0px 0px",
                                                display: 'inline',
                                                float: 'left'
                                            }}>
                                            Regular</InputLabel>}
                                    />
                                </div>
                                <div className={RulesLocationLeftClasses.header_child}>
                                    <FormControlLabel size="small" sx={{ margin: "0px", padding: "0px" }}
                                        control={
                                            <Switch
                                                size="small"
                                                name="check2"
                                                // checked={checked?false:true}
                                                onChange={handleswitchcheck}
                                                // onClick={() => { setCheck1(!check1) }}
                                                inputProps={{ 'aria-label': 'controlled' }}
                                            />
                                        }
                                        label={<InputLabel
                                            sx={{
                                                fontWeight: "bold",
                                                fontSize: "14px",
                                                margin: "0px 0px 0px 0px",
                                                padding: "0px 0px 0px 0px",
                                                display: 'inline',
                                                float: 'left'
                                            }}>
                                            Promotional</InputLabel>}
                                    />
                                </div>
                                <div className={RulesLocationLeftClasses.header_child}>
                                    <FormControlLabel size="small" sx={{ margin: "0px", padding: "0px" }}
                                        control={
                                            <Switch
                                                size="small"
                                                name="check3"
                                                // checked={checked?false:true}
                                                onChange={handleswitchcheck}
                                                // onClick={() => { setCheck1(!check1) }}
                                                inputProps={{ 'aria-label': 'controlled' }}
                                            />
                                        }
                                        label={<InputLabel
                                            sx={{
                                                fontWeight: "bold",
                                                fontSize: "14px",
                                                margin: "0px 0px 0px 0px",
                                                padding: "0px 0px 0px 0px",
                                                display: 'inline',
                                                float: 'left'
                                            }}>
                                            Clearance</InputLabel>}
                                    />
                                </div>
                            </div>
                        </div>
                    }
                </div>




                {(allocDetails.length > 0 ? allocDetails[0].ALLOC_LEVEL == 'Style Diff' : allocDetails[0].ALLOC_LEVEL == 'Sku') ?
                    <div>
                        <FormControlLabel size="small" sx={{ margin: "0px", padding: "0px" }}
                            control={
                                <Switch
                                    size="small"
                                    name="check4"
                                    // checked={checked?false:true}
                                    onChange={handleswitchcheck}
                                    // onClick={() => { setCheck1(!check1) }}
                                    inputProps={{ 'aria-label': 'controlled' }}
                                />
                            }
                            label={<InputLabel
                                sx={{
                                    fontWeight: "bold",
                                    fontSize: "14px",
                                    margin: "0px 0px 0px 0px",
                                    padding: "0px 0px 0px 0px",
                                    display: 'inline',
                                    float: 'left'
                                }}>
                                Use Size Profile</InputLabel>}
                        />
                    </div> : null}

                <div>
                    <FormControlLabel size="small" sx={{ margin: "0px", paddingBottom: "5px" }}
                        control={
                            <Switch
                                size="small"
                                name="check5"
                                // checked={checked?false:true}
                                onChange={handleswitchcheck}
                                // onClick={() => { setCheck1(!check1) }}
                                inputProps={{ 'aria-label': 'controlled' }}
                            />
                        }
                        label={<InputLabel
                            sx={{
                                fontWeight: "bold",
                                fontSize: "14px",
                                margin: "0px 0px 0px 0px",
                                padding: "0px 0px 0px 2px",
                                display: 'inline',
                                float: 'left'
                            }}>
                            Default Auto Presentation Min and Qty Limits</InputLabel>}
                    />
                </div>

                <div>
                    <div className={RulesLocationLeftClasses.header_child}>
                        <InputLabel sx={{ fontWeight: "bold", fontSize: "16px", margin: "2px 0px 0px 2px", display: 'flex', float: 'left' }}>
                            Rules Template :</InputLabel>
                    </div>
                    <div className={RulesLocationLeftClasses.header_child}>
                        <Select
                            maxMenuHeight={180}
                            classNamePrefix="mySelect"
                            getOptionLabel={option =>
                                `${option.label.toString()}`}
                            getOptionValue={option => option.label}
                            options={optionsTemplates.length > 0 ? optionsTemplates : []}
                            isSearchable={true}
                            menuPlacement="auto"
                            isMulti
                            isClearable={true}
                            closeMenuOnSelect={true}
                            hideSelectedOptions={false}
                            // sx={{ width: "100%" }}
                            styles={styleSelect1}
                            components={animatedComponents}
                        />
                    </div>
                    <div className={RulesLocationLeftClasses.header_child}>
                        <Button
                            sx={{
                                // fontSize: "12px",
                                margin: "0px 0px 0px 0px",
                            }}
                            onClick={handleClickOpen}
                            variant="contained">
                            Apply
                        </Button>
                    </div>

                    {/* <button className='sub-container-btns' onClick={handleClickOpen}>Apply</button> */}
                </div>


                <div>
                    <div className={RulesLocationLeftClasses.header_child}>
                        <div>
                            <InputLabel sx={{ fontWeight: "bold", fontSize: "12px", margin: "12px 0px 0px 2px", display: 'flex', float: 'left' }}>
                                Rule Type</InputLabel>
                        </div>
                        <div>
                            <Select
                                maxMenuHeight={180}
                                classNamePrefix="mySelect"
                                getOptionLabel={option =>
                                    `${option.CODE_DESC.toString()}`}
                                getOptionValue={option => option.CODE_DESC}
                                options={ruleType.length > 0 ? ruleType : []}
                                isSearchable={true}
                                onChange={selectRuleType}
                                menuPlacement="auto"
                                // isMulti
                                isClearable={true}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                // sx={{ width: "100%" }}
                                styles={styleSelect1}
                                components={animatedComponents}
                            />
                        </div>
                    </div>

                    <div className={RulesLocationLeftClasses.header_child}>
                        <div>
                            <InputLabel sx={{ fontWeight: "bold", fontSize: "12px", margin: "12px 0px 0px 2px", display: 'flex', float: 'left' }}>
                                Need</InputLabel>
                        </div>
                        <div>
                            <Select
                                maxMenuHeight={180}
                                classNamePrefix="mySelect"
                                getOptionLabel={option =>
                                    `${option.CODE_DESC.toString()}`}
                                getOptionValue={option => option.CODE_DESC}
                                options={Need.length > 0 ? Need : []}
                                isSearchable={true}
                                onChange={selectNEEDType}
                                menuPlacement="auto"
                                // isMulti
                                isClearable={true}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                // sx={{ width: "100%" }}
                                styles={styleSelect1}
                                components={animatedComponents}
                            />
                        </div>
                    </div>

                    <div className={RulesLocationLeftClasses.header_child}>
                        <div>
                            <InputLabel sx={{ fontWeight: "bold", fontSize: "12px", margin: "12px 0px 0px 2px", display: 'flex', float: 'left' }}>
                                Hierarchy</InputLabel>
                        </div>
                        <div>
                            <Select
                                maxMenuHeight={180}
                                classNamePrefix="mySelect"
                                getOptionLabel={option =>
                                    `${option.CODE_DESC.toString()}`}
                                getOptionValue={option => option.CODE_DESC}
                                options={Hierarchy.length > 0 ? Hierarchy : []}
                                isSearchable={true}
                                onChange={selectHierarchy}
                                menuPlacement="auto"
                                // isMulti
                                isClearable={true}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                // sx={{ width: "100%" }}
                                styles={styleSelect1}
                                components={animatedComponents}
                            />
                        </div>
                    </div>

                    <div className={RulesLocationLeftClasses.header_child}>
                        <div>
                            <InputLabel sx={{ fontWeight: "bold", fontSize: "12px", margin: "12px 0px 0px 2px", display: 'flex', float: 'left' }}>
                                Allocate To</InputLabel>
                        </div>
                        <div>
                            <Select
                                maxMenuHeight={180}
                                classNamePrefix="mySelect"
                                getOptionLabel={option =>
                                    `${option.CODE_DESC.toString()}`}
                                getOptionValue={option => option.CODE_DESC}
                                options={Allocateto.length > 0 ? Allocateto : []}
                                isSearchable={true}
                                onChange={selectAllocateTo}
                                menuPlacement="auto"
                                // isMulti
                                isClearable={true}
                                closeMenuOnSelect={true}
                                hideSelectedOptions={false}
                                // sx={{ width: "100%" }}
                                styles={styleSelect1}
                                components={animatedComponents}
                            />
                        </div>
                    </div>
                </div>

                <div>
                    {Inventory_Range()}
                </div>
            </div>

            {/* <div sx={{ display: "flex", flexDirection: "row" }}>
                <Grid id="top-row" container spacing={0}>
                    <div className={RulesLocationLeftClasses.course_box}>
                        {Inventory_Range()}
                    </div>
                </Grid>
            </div> */}

            {/* AKHIL  End*/}


        </Box>
    )
})

export default LeftContainer